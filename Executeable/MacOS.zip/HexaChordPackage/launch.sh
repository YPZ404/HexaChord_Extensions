#!/bin/sh
cd "$(dirname "$0")"
java -jar HexaChord-uber.jar