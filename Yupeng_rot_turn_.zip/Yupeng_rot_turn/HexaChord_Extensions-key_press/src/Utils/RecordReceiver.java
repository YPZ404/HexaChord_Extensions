package Utils;
import javax.sound.midi.MidiMessage;
import javax.sound.midi.Receiver;

public class RecordReceiver implements Receiver{

	@Override
	public void send(MidiMessage message, long timeStamp) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void close() {
		// TODO Auto-generated method stub
		
	}

}
