package Utils;

public class Nyi extends Exception {
	private static final long serialVersionUID = 9151359050662739726L;

	public Nyi() {
		super("Not Yet Implemented");
	}
}
