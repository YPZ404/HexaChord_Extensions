package Model.Music;

public interface MidiPlayerListener {
	
	void tick_change(long new_tick);

}
