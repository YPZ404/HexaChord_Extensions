package Model.Music;

import edu.stanford.math.plex.Packed2Simplex;

public class ZeroSimplex extends Packed2Simplex{

	public ZeroSimplex(){
		super();
	}
}
