package Model.Music;

public class Constant {

	public static final int N = 12;
}
