package Model.Music;

import java.util.TreeMap;

public class PitchClassSetStream extends TreeMap<Long,PitchClassSet>{

	private static final long serialVersionUID = 1L;

	public PitchClassSetStream(){
		super();
		
	}
	
}
