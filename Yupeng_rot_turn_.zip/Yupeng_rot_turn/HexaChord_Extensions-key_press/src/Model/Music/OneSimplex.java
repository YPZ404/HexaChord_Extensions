package Model.Music;

import edu.stanford.math.plex.Packed2Simplex;

public class OneSimplex extends Packed2Simplex{

	public OneSimplex(){
		super();
	}
}
