package Model.Music;

import edu.stanford.math.plex.Packed4Simplex;

public class TwoSimplex extends Packed4Simplex{

	public TwoSimplex(){
		super();
	}
}
