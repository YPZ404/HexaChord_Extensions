package Model.Music;

import edu.stanford.math.plex.Packed4Simplex;

public class ThreeSimplex extends Packed4Simplex{

	public ThreeSimplex(){
		super();
	}
}
