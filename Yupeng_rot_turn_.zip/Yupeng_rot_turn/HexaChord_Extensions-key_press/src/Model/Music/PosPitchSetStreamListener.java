package Model.Music;

public interface PosPitchSetStreamListener {

	void pos_change(long new_pos);
	
}
