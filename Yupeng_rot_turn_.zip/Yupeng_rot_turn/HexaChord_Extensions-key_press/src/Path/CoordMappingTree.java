package Path;

import java.util.ArrayList;
import java.util.TreeMap;

public class CoordMappingTree extends TreeMap<Long,ArrayList<CoordMapping>>{
	
	private static final long serialVersionUID = 1L;

	public CoordMappingTree(){
		super();
	}

}
