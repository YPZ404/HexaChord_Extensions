package Path;

public interface TransformationInTonnetz {

}
