package edu.stanford.math.plex_viewer.color;

public class ColorSchemeUtility {
	
}
